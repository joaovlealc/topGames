﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace gammer_shopp
{
    class Artigo
    {
        public int Id { get; set; }
        public string nome { get; set; }
        public int quantidade { get; set; }
        public decimal valor { get; set; }

        public List<Artigo> listaArtigo()
        {
            List<Artigo> li = new List<Artigo>();
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM produto";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Artigo a = new Artigo();
                a.Id = (int)dr["Id"];
                a.nome = dr["nome"].ToString();
                a.quantidade = (int)dr["quantidade"];
                a.valor = Convert.ToDecimal(dr["valor"]);
                li.Add(a);
            }
            return li;
        }

        public void Inserir(string nome, int quantidade, decimal valor)
        {
            string num = valor.ToString();
            num = num.Replace(',', '.');
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "INSERT INTO produto(nome,quantidade,valor) VALUES ('" + nome + "'," + quantidade + ",'" + num + "')";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConecta.FecharConexao();
        }

        public void Localiza(int id)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM produto WHERE Id='" + id + "'";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                nome = dr["nome"].ToString();
                quantidade = (int)dr["quantidade"];
                valor = (decimal)dr["valor"];
            }
        }

        public void Atualizar(int id, string nome, int quantidade, decimal valor)
        {
            string num = valor.ToString();
            num = num.Replace(',', '.');
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "UPDATE produto SET nome='" + nome + "',quantidade=" + quantidade + ",valor='" + num + "' WHERE Id = '" + id + "'";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConecta.FecharConexao();
        }

        public void Exclui(int id)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "DELETE FROM produto WHERE Id='" + id + "'";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConecta.FecharConexao();
        }
    }
}
}
