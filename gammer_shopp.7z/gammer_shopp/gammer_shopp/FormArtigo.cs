﻿using System;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace gammer_shopp
{
    public partial class FormArtigo : Form
    {
        public FormArtigo()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtID.Text = "";
            txtNome.Text = "";
            txtQuantidade.Text = "";
            txtPreco.Text = "";
        }

        private void FormArtigo_Load(object sender, EventArgs e)
        {
            Artigo art = new Artigo();
            List<Artigo> artigos = art.listaArtigo();
            dgvArtigo.DataSource = artigos;
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                int qtde = Int32.Parse(txtQuantidade.Text);
                Artigo artigo = new Artigo();
                artigo.Inserir(txtNome.Text, qtde, Convert.ToDecimal(txtPreco.Text));
                MessageBox.Show("Artigo cadastrado com sucesso!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Artigo> art = artigo.listaArtigo();
                dgvArtigo.DataSource = art;
                txtID.Text = "";
                txtNome.Text = "";
                txtQuantidade.Text = "";
                txtPreco.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Int32.Parse(txtID.Text);
                int qtde = Int32.Parse(txtQuantidade.Text);
                Artigo artigo = new Artigo();
                artigo.Atualizar(id, txtNome.Text, qtde, Convert.ToDecimal(txtPreco.Text));
                MessageBox.Show("Artigo atualizado com sucesso!", "Atualização", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Artigo> art = artigo.listaArtigo();
                dgvArtigo.DataSource = art;
                txtID.Text = "";
                txtNome.Text = "";
                txtQuantidade.Text = "";
                txtPreco.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnExcuir_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Int32.Parse(txtID.Text);
                Artigo artigo = new Artigo();
                artigo.Exclui(id);
                MessageBox.Show("Artigo excluído com sucesso!", "Exclusão", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Artigo> art = artigo.listaArtigo();
                dgvArtigo.DataSource = art;
                txtID.Text = "";
                txtNome.Text = "";
                txtQuantidade.Text = "";
                txtPreco.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void txtNome_Leave(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\programas\\topGames-main\\gammer_shopp\\gammer_shopp\\DbTopGames.mdf;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("SELECT nome FROM artigos WHERE nome=@nome", con);
            cmd.Parameters.AddWithValue("@nome", SqlDbType.NChar).Value = txtNome.Text;
            cmd.CommandType = CommandType.Text;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            int ctr = 0;
            while (dr.Read())
            {
                ctr++;
            }
            if (ctr == 1)
            {
                MessageBox.Show("Este artigo já existe em nossa base de dados!", "Registro repetido!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtNome.Text = "";
                txtNome.Focus();
                con.Close();
            }
            else
            {

            }
        }

        private void dgvArtigo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = this.dgvArtigo.Rows[e.RowIndex];
            txtID.Text = row.Cells[0].Value.ToString();
            txtNome.Text = row.Cells[1].Value.ToString();
            txtQuantidade.Text = row.Cells[2].Value.ToString();
            txtPreco.Text = row.Cells[3].Value.ToString();
        }
    }
    }
}
