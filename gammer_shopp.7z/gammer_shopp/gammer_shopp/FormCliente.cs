﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gammer_shopp
{
    public partial class FormCliente : Form
    {
        public FormCliente()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                Cliente cliente = new Cliente();
                cliente.Inserir(txtCpf.Text, txtNome.Text, txtCep.Text, txtEndereco.Text, txtBairro.Text, txtCidade.Text, txtCelular.Text, txtEmail.Text, dtpDtNascimento.Value);
                MessageBox.Show("Cliente cadastrado com sucesso!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Cliente> cli = cliente.listacliente();
                dgvCliente.DataSource = cli;
                txtCpf.Text = "";
                txtNome.Text = "";
                txtBairro.Text = "";
                txtEndereco.Text = "";
                txtCep.Text = "";
                txtCidade.Text = "";
                txtEmail.Text = "";
                txtCelular.Text = "";
                this.dtpDtNascimento.Value = DateTime.Now.Date;
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }
    }
}
